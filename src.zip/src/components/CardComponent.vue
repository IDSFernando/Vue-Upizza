<template>
    <stripe-element
        type="card"
        :stripe="stripeKey"
        @change="cdcompleted = $event.complete"
    >
    <template slot-scope="slotProps">
        <v-btn color="success" :disabled="!cdcompleted" @click="payByCard(slotProps)">Pagar</v-btn>
    </template>
</stripe-element>
</template>

<script>
    StripeElement = require('vue-stripe-better-elements')
    export default {
        components: {
            StripeElement
        },
        data: () => ({
            stripeKey: 'pk_test_0O64VFv2CpBBw2tXLQjY41tf00kIe8lGmk',
            cdcompleted: false
        }),
        methods: {
            payByCard(slotProps){
                slotProps.elements.createToken().then(console.log()).catch(console.error)
            }
        }
    }
</script>
