<template>
    <Card/>
</template>

<script>

import {Vue,Component} from 'vue-property-decorator'
import { Card } from '@/components/CardComponent'

@Component({
components: {
    Card
  },
})


export default class Card extends Vue{}
</script>
